/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author hp
 */
@Entity
@Table(name = "proyectos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Proyectos.findAll", query = "SELECT p FROM Proyectos p")
    , @NamedQuery(name = "Proyectos.findByIdProyecto", query = "SELECT p FROM Proyectos p WHERE p.idProyecto = :idProyecto")
    , @NamedQuery(name = "Proyectos.findByDescripcion", query = "SELECT p FROM Proyectos p WHERE p.descripcion = :descripcion")
    , @NamedQuery(name = "Proyectos.findByFechaInicio", query = "SELECT p FROM Proyectos p WHERE p.fechaInicio = :fechaInicio")
    , @NamedQuery(name = "Proyectos.findByFechaEntrega", query = "SELECT p FROM Proyectos p WHERE p.fechaEntrega = :fechaEntrega")
    , @NamedQuery(name = "Proyectos.findByMontoCotizado", query = "SELECT p FROM Proyectos p WHERE p.montoCotizado = :montoCotizado")})
public class Proyectos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "id_proyecto")
    private String idProyecto;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "descripcion")
    private String descripcion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_inicio")
    @Temporal(TemporalType.DATE)
    private Date fechaInicio;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fecha_entrega")
    @Temporal(TemporalType.DATE)
    private Date fechaEntrega;
    @Basic(optional = false)
    @NotNull
    @Column(name = "monto_cotizado")
    private double montoCotizado;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idProyecto")
    private List<Requerimientos> requerimientosList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idProyecto")
    private List<EquipoDesarrollo> equipoDesarrolloList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "proyectos")
    private List<Sprints> sprintsList;

    public Proyectos() {
    }

    public Proyectos(String idProyecto) {
        this.idProyecto = idProyecto;
    }

    public Proyectos(String idProyecto, String descripcion, Date fechaInicio, Date fechaEntrega, double montoCotizado) {
        this.idProyecto = idProyecto;
        this.descripcion = descripcion;
        this.fechaInicio = fechaInicio;
        this.fechaEntrega = fechaEntrega;
        this.montoCotizado = montoCotizado;
    }

    public String getIdProyecto() {
        return idProyecto;
    }

    public void setIdProyecto(String idProyecto) {
        this.idProyecto = idProyecto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(Date fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public double getMontoCotizado() {
        return montoCotizado;
    }

    public void setMontoCotizado(double montoCotizado) {
        this.montoCotizado = montoCotizado;
    }

    @XmlTransient
    public List<Requerimientos> getRequerimientosList() {
        return requerimientosList;
    }

    public void setRequerimientosList(List<Requerimientos> requerimientosList) {
        this.requerimientosList = requerimientosList;
    }

    @XmlTransient
    public List<EquipoDesarrollo> getEquipoDesarrolloList() {
        return equipoDesarrolloList;
    }

    public void setEquipoDesarrolloList(List<EquipoDesarrollo> equipoDesarrolloList) {
        this.equipoDesarrolloList = equipoDesarrolloList;
    }

    @XmlTransient
    public List<Sprints> getSprintsList() {
        return sprintsList;
    }

    public void setSprintsList(List<Sprints> sprintsList) {
        this.sprintsList = sprintsList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idProyecto != null ? idProyecto.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Proyectos)) {
            return false;
        }
        Proyectos other = (Proyectos) object;
        if ((this.idProyecto == null && other.idProyecto != null) || (this.idProyecto != null && !this.idProyecto.equals(other.idProyecto))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelos.Proyectos[ idProyecto=" + idProyecto + " ]";
    }
    
}
