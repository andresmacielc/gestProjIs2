/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author hp
 */
@Entity
@Table(name = "requerimientos")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Requerimientos.findAll", query = "SELECT r FROM Requerimientos r")
    , @NamedQuery(name = "Requerimientos.findByIdRequerimiento", query = "SELECT r FROM Requerimientos r WHERE r.idRequerimiento = :idRequerimiento")
    , @NamedQuery(name = "Requerimientos.findByNombre", query = "SELECT r FROM Requerimientos r WHERE r.nombre = :nombre")
    , @NamedQuery(name = "Requerimientos.findByDimension", query = "SELECT r FROM Requerimientos r WHERE r.dimension = :dimension")
    , @NamedQuery(name = "Requerimientos.findByComentarios", query = "SELECT r FROM Requerimientos r WHERE r.comentarios = :comentarios")})
public class Requerimientos implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "id_requerimiento")
    private String idRequerimiento;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "nombre")
    private String nombre;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "dimension")
    private String dimension;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 2147483647)
    @Column(name = "comentarios")
    private String comentarios;
    @JoinColumn(name = "id_estado", referencedColumnName = "id_estado")
    @ManyToOne(optional = false)
    private Estados idEstado;
    @JoinColumn(name = "id_funcion", referencedColumnName = "id_funcion")
    @ManyToOne(optional = false)
    private Funciones idFuncion;
    @JoinColumn(name = "id_prioridad", referencedColumnName = "id_prioridad")
    @ManyToOne(optional = false)
    private Prioridades idPrioridad;
    @JoinColumn(name = "id_proyecto", referencedColumnName = "id_proyecto")
    @ManyToOne(optional = false)
    private Proyectos idProyecto;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "idRequerimiento")
    private List<Actividades> actividadesList;

    public Requerimientos() {
    }

    public Requerimientos(String idRequerimiento) {
        this.idRequerimiento = idRequerimiento;
    }

    public Requerimientos(String idRequerimiento, String nombre, String dimension, String comentarios) {
        this.idRequerimiento = idRequerimiento;
        this.nombre = nombre;
        this.dimension = dimension;
        this.comentarios = comentarios;
    }

    public String getIdRequerimiento() {
        return idRequerimiento;
    }

    public void setIdRequerimiento(String idRequerimiento) {
        this.idRequerimiento = idRequerimiento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDimension() {
        return dimension;
    }

    public void setDimension(String dimension) {
        this.dimension = dimension;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    public Estados getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(Estados idEstado) {
        this.idEstado = idEstado;
    }

    public Funciones getIdFuncion() {
        return idFuncion;
    }

    public void setIdFuncion(Funciones idFuncion) {
        this.idFuncion = idFuncion;
    }

    public Prioridades getIdPrioridad() {
        return idPrioridad;
    }

    public void setIdPrioridad(Prioridades idPrioridad) {
        this.idPrioridad = idPrioridad;
    }

    public Proyectos getIdProyecto() {
        return idProyecto;
    }

    public void setIdProyecto(Proyectos idProyecto) {
        this.idProyecto = idProyecto;
    }

    @XmlTransient
    public List<Actividades> getActividadesList() {
        return actividadesList;
    }

    public void setActividadesList(List<Actividades> actividadesList) {
        this.actividadesList = actividadesList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idRequerimiento != null ? idRequerimiento.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Requerimientos)) {
            return false;
        }
        Requerimientos other = (Requerimientos) object;
        if ((this.idRequerimiento == null && other.idRequerimiento != null) || (this.idRequerimiento != null && !this.idRequerimiento.equals(other.idRequerimiento))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelos.Requerimientos[ idRequerimiento=" + idRequerimiento + " ]";
    }
    
}
