package service;

import java.util.Set;
import javax.ws.rs.core.Application;

/**
 *
 * @author desap
 */
@javax.ws.rs.ApplicationPath("recursos")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<>();
        addRestResourceClasses(resources);
        return resources;
    }

    /**
     * Do not modify addRestResourceClasses() method.
     * It is automatically populated with
     * all resources defined in the project.
     * If required, comment out calling this method in getClasses().
     */
    private void addRestResourceClasses(Set<Class<?>> resources) {
        resources.add(service.ActividadesFacadeREST.class);
        resources.add(service.CargosFacadeREST.class);
        resources.add(service.EquipoDesarrolloFacadeREST.class);
        resources.add(service.EstadosFacadeREST.class);
        resources.add(service.FuncionesFacadeREST.class);
        resources.add(service.KanbanFacadeREST.class);
        resources.add(service.PermisosFacadeREST.class);
        resources.add(service.PersonasFacadeREST.class);
        resources.add(service.PrioridadesFacadeREST.class);
        resources.add(service.ProyectosFacadeREST.class);
        resources.add(service.RequerimientosFacadeREST.class);
        resources.add(service.RolesFacadeREST.class);
        resources.add(service.SprintsFacadeREST.class);
    }
    
}